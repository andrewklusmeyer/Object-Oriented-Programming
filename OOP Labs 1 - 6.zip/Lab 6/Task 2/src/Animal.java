//Define a new class named Animal. This class is meant to be a general representation of animals
public class Animal
{
    //Define the say method for the Animal class. This method is intended to represent
    //the sound an animal makes
    public String say()
    {
        //This method returns an empty string because it is general for all
        //animals; specific animal sounds will be defined in subclasses
        return "";
    }
}
