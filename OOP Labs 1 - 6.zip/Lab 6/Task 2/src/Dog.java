//Define a new class named Dog which inherits from the Animal class
public class Dog extends Animal
{
    //Define the say method for the Dog class
    @Override
    public String say()
    {
        //Return the sound a dog makes
        return "arf-arf";
    }
}
