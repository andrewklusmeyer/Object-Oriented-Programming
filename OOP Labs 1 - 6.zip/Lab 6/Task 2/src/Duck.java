//Define a new class named Duck which inherits from the Animal class
public class Duck extends Animal
{
    //Define the say method for the Duck class
    @Override

    public String say()
    {
        //Return the sound a duck makes
        return "quack-quack";
    }
}
