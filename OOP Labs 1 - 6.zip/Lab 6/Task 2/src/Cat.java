//Define a new class named Cat which inherits from the Animal class

public class Cat extends Animal
{
    //Define the say method for the Cat class
    @Override
    public String say()
    {
        //Return the sound a cat makes
        return "meow-meow";
    }
}
