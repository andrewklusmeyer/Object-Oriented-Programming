
public class Task2Demo
{
    public static void main(String[] args)
    {
        //Create an instance of the Cat class, referred to by the Animal type
        Animal cat = new Cat();

        //Create an instance of the Dog class, referred to by the Animal type
        Animal dog = new Dog();

        //Create an instance of the Duck class, referred to by the Animal type
        Animal duck = new Duck();

        //Print out what the cat says
        System.out.println("\nCat says:\n" + cat.say() + "\n");

        //Print out what the dog says
        System.out.println("Dog says:\n" + dog.say() + "\n");

        //Print out what the duck says
        System.out.println("Duck says:\n" + duck.say() + "\n");
    }
}
