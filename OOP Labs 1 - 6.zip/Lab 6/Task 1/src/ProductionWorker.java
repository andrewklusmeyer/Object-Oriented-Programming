//Declaring a class named ProductionWorker which inherits from the Employee class.
public class ProductionWorker extends Employee
{
    private int shift;
    private double payRate;
    public static final int DAY_SHIFT = 1;
    public static final int NIGHT_SHIFT = 2;

    //Parameterized constructor to initialize a ProductionWorker object with specific values
    public ProductionWorker(String name, String num, String date, int shift, double rate)
    {
        //Calling the parameterized constructor of the parent class Employee
        super(name, num, date);

        this.shift = shift;
        this.payRate = rate;
    }

    //Default constructor for the ProductionWorker class
    public ProductionWorker() {}

    //Getter method to retrieve the value of the 'shift' instance variable
    public int getShift()
    {
        return shift;
    }

    //Setter method to set or update the value of the 'shift' instance variable
    public void setShift(int shift)
    {
        this.shift = shift;
    }

    //Getter method to retrieve the value of the 'payRate' instance variable
    public double getPayRate()
    {
        return payRate;
    }

    //Setter method to set or update the value of the 'payRate' instance variable
    public void setPayRate(double payRate)
    {
        this.payRate = payRate;
    }

    //Override the default 'toString()' method to return a formatted string representation of the ProductionWorker object
    @Override
    public String toString()
    {
        //Determines if the shift is "Day" or "Night" based on the value of 'shift'
        String shiftStr = (shift == DAY_SHIFT) ? "Day" : "Night";

        return super.toString() + "\nShift: " + shiftStr + "\nHourly Pay Rate: $" + payRate;
    }
}
