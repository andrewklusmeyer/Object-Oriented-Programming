
public class Task1Demo
{

    public static void main(String[] args)
    {
        //Create workerOne using default constructor
        ProductionWorker workerOne = new ProductionWorker();

        //Set values using setters
        workerOne.setName("John Smith");
        workerOne.setEmployeeNumber("123-A");
        workerOne.setHireDate("11-15-2005");
        workerOne.setShift(ProductionWorker.DAY_SHIFT);
        workerOne.setPayRate(16.50);

        //Create workerTwo using parametrized constructor
        ProductionWorker workerTwo = new ProductionWorker("Joan Jones", "222-L", "12-12-2005", ProductionWorker.NIGHT_SHIFT, 18.50);

        //Display the workers using getters (though toString() can be directly used as seen when displaying workerTwo)
        System.out.println("The first production worker.");
        System.out.println("Name: " + workerOne.getName() +
                "\nEmployee Number: " + workerOne.getEmployeeNumber() +
                "\nHire Date: " + workerOne.getHireDate() +
                "\nShift: " + (workerOne.getShift() == ProductionWorker.DAY_SHIFT ? "Day" : "Night") +
                "\nHourly Pay Rate: $" + workerOne.getPayRate());

        System.out.println("\nThe second production worker.\n" + workerTwo);

    }
}

