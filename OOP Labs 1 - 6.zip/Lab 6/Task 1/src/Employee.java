
public class Employee
{
    private String name;
    private String employeeNumber;
    private String hireDate;

    //Parameterized constructor to initialize an Employee object with specific values
    public Employee(String name, String employeeNumber, String hireDate)
    {
        this.name = name;
        this.employeeNumber = employeeNumber;
        this.hireDate = hireDate;
    }

    //Default constructor for the Employee class. Initializes an Employee object without specific values
    public Employee() {}

    //Getter method to retrieve the value of the 'name' instance variable
    public String getName()
    {
        return name;
    }

    //Setter method to set or update the value of the 'name' instance variable
    public void setName(String name)
    {
        this.name = name;
    }

    //Getter method to retrieve the value of the 'employeeNumber' instance variable
    public String getEmployeeNumber()
    {
        return employeeNumber;
    }

    //Setter method to set or update the value of the 'employeeNumber' instance variable
    public void setEmployeeNumber(String employeeNumber)
    {
        this.employeeNumber = employeeNumber;
    }

    //Getter method to retrieve the value of the 'hireDate' instance variable
    public String getHireDate()
    {
        return hireDate;
    }

    //Setter method to set or update the value of the 'hireDate' instance variable
    public void setHireDate(String hireDate)
    {
        this.hireDate = hireDate;
    }

    //Private method to check if the provided 'empNum' matches the current 'employeeNumber'
    private boolean isValidEmpNum(String empNum)
    {
        //Returns true if 'empNum' matches 'employeeNumber', otherwise returns false.
        return empNum.equals(employeeNumber);
    }

    //Override the default 'toString()' method to return a formatted string representation of the Employee object
    @Override
    public String toString()
    {
        return "Name: " + name + "\nEmployee Number: " + employeeNumber + "\nHire Date: " + hireDate;
    }
}
