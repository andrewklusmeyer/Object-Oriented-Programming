//Declare a class named 'Trapezoid' that inherits from the abstract class 'Shape'
public class Trapezoid extends Shape
{
    private double lowerBase;
    private double upperBase;
    private double height;

    //Define a constructor for the 'Trapezoid' class
    public Trapezoid(double lowerBase, double upperBase, double height)
    {
        this.lowerBase = lowerBase;
        this.upperBase = upperBase;
        this.height = height;
    }

    //Override the abstract 'getArea' method from the 'Shape' class
    @Override
    public double getArea()
    {
        //Calculate and return the area of the trapezoid using the formula: 0.5 * (lowerBase + upperBase) * height
        return 0.5 * (lowerBase + upperBase) * height;
    }

    //Override the 'toString' method
    @Override
    public String toString()
    {
        //Return a formatted string that specifies the shape as a trapezoid and includes its area
        return "I am a trapezoid shape of area: " + String.format("%.2f", getArea());
    }
}
