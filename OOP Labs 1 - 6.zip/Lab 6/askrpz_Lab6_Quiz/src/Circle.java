//Declare a class named 'Circle' that inherits from the abstract class 'Shape'
public class Circle extends Shape
{
    private static final double PI = 3.14159;
    private double radius;

    //Define a constructor for the 'Circle' class
    public Circle(double radius)
    {
        this.radius = radius;
    }

    //Override the abstract 'getArea' method from the 'Shape' class
    @Override
    public double getArea()
    {
        //Calculate and return the area of the circle using the formula: PI * radius^2
        return PI * radius * radius;
    }

    //Override the 'toString' method
    @Override
    public String toString()
    {
        //Return a formatted string that specifies the shape as a circle and includes its area
        return "I am a circle shape of area: " + String.format("%.2f", getArea());
    }
}
