//Declare an abstract class named 'Shape'
public abstract class Shape
{
    //Declare an abstract method named 'getArea' that returns a double value
    //This means that any class inheriting from 'Shape' must provide an implementation for this method
    public abstract double getArea();

}
