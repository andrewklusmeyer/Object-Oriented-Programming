//Declare a class named 'Rectangle' that inherits from the abstract class 'Shape'
public class Rectangle extends Shape
{
    private double length;
    private double width;

    //Define a constructor for the 'Rectangle' class
    public Rectangle(double length, double width)
    {
        this.length = length;
        this.width = width;
    }

    //Override the abstract 'getArea' method from the 'Shape' class
    @Override
    public double getArea()
    {
        //Calculate and return the area of the rectangle using the formula: length * width
        return length * width;
    }

    //Override the 'toString' method
    @Override
    public String toString()
    {
        //Return a formatted string that specifies the shape as a rectangle and includes its area
        return "I am a rectangle shape of area: " + String.format("%.2f", getArea());
    }
}
