//Defines a public class named Rank
public class Rank
{
    //Declares a private double variable named queryMark
    private double queryMark;

    //Constructor: Initializes the queryMark variable with the provided 'mark'
    public Rank(double mark)
    {
        queryMark = mark;
    }

    //Method to determine and return a rank based on the value of queryMark
    public String getRank()
    {
        //Checks if queryMark is greater than or equal to 90
        if (queryMark >= 90)
        {
            //If true, returns "Exceeds Expectations"
            return "Exceeds Expectations";
        }
        else
        {
            //If queryMark is less than 90, checks if it's greater than or equal to 70
            if (queryMark >= 70)
            {
                //If true, returns "Meets Expectations"
                return "Meets Expectations";
            }
            else
            {
                //If queryMark is less than 70, checks if it's greater than or equal to 50
                if (queryMark >= 50)
                {
                    //If true, returns "Below Expectations"
                    return "Below Expectations";
                }
                else
                {
                    //If none of the above conditions are met, returns "Unacceptable"
                    return "Unacceptable";
                }
            }
        }
    }
}
