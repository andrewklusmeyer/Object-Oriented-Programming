import java.util.Scanner;

public class RankDemo
{
    public static void main(String args[])
    {
        double mark;

        Scanner keyboard = new Scanner(System.in);

        System.out.print("Enter the student's mark: ");
        mark = keyboard.nextDouble();

        Rank converter = new Rank(mark);

        System.out.println("The mark " + mark + " is ranked as " + converter.getRank());
    }
}