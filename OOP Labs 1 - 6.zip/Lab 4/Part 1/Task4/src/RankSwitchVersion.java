//Defines a public class named RankSwitchVersion
public class RankSwitchVersion
{
    //Declares a private double variable named queryMark
    private double queryMark;

    //Constructor: Initializes the queryMark variable with the provided 'mark'
    public RankSwitchVersion(double mark)
    {
        queryMark = mark;
    }

    //Method to determine and returns a rank based on the value of queryMark
    public String getRank()
    {
        //Uses a switch statement to determine the rank based on the integer part of queryMark divided by 10
        switch ((int) queryMark / 10)
        {
            case 10:
                //If queryMark is in the range [100, 90), returns "Exceeds Expectations"
                return "Exceeds Expectations";
            case 9:
                //If queryMark is in the range [90, 80), returns "Exceeds Expectations"
                return "Exceeds Expectations";
            case 8:
                //If queryMark is in the range [80, 70), returns "Meets Expectations"
                return "Meets Expectations";
            case 7:
                //If queryMark is in the range [70, 60), returns "Meets Expectations"
                return "Meets Expectations";
            case 6:
                //If queryMark is in the range [60, 50), returns "Below Expectations"
                return "Below Expectations";
            case 5:
                //If queryMark is in the range [50, 40), returns "Below Expectations"
                return "Below Expectations";
            case 4:
                //If queryMark is in the range [40, 30), returns "Unacceptable"
                return "Unacceptable";
            case 3:
                //If queryMark is in the range [30, 20), returns "Unacceptable"
                return "Unacceptable";
            case 2:
                //If queryMark is in the range [20, 10), returns "Unacceptable"
                return "Unacceptable";
            case 1:
                //If queryMark is in the range [10, 0), returns "Unacceptable"
                return "Unacceptable";
            case 0:
                //If queryMark is 0, return "Unacceptable"
                return "Unacceptable";
            default:
                //If none of the above cases match, returns "Invalid"
                return "Invalid";
        }
    }
}
