//Imports the Scanner class from the java.util package, allowing user input
import java.util.Scanner;

//Defines a public class named IsLeapYearDemo
public class IsLeapYearDemo
{
    public static void main(String[] args)
    {
        //Declares an integer variable to store the user's input year
        int inputYear;

        //Creates a Scanner object named 'keyboard' to read input from the keyboard
        Scanner keyboard = new Scanner(System.in);

        //Prompts the user to enter a year
        System.out.printf("Enter the query year: ");

        //Reads the year entered by the user and store it in 'inputYear'
        inputYear = keyboard.nextInt();

        //Creates an instance of the 'IsLeapYear' class with the 'inputYear' as an argument
        IsLeapYear year = new IsLeapYear(inputYear);

        //Checks if the year is divisible by 4
        if(inputYear % 4 == 0)
        {
            //If it is divisible by 4, checks if it is not divisible by 100
            if (inputYear % 100 != 0)
            {
                //Displays a message indicating that the year is a leap year
                System.out.println("The following year you entered is a leap year: " + year.getQueryYear());
            }
            else
            {
                //If it is divisible by 100, checks if it is also divisible by 400
                if (inputYear % 400 == 0)
                {
                    //Displays a message indicating that the year is a leap year
                    System.out.println("The following year you entered is a leap year: " + year.getQueryYear());
                }
                else
                {
                    //Displays a message indicating that the year is not a leap year
                    System.out.println("The following year you entered is not a leap year: " + year.getQueryYear());
                }
            }
        }
        else
        {
            //Displays a message indicating that the year is not a leap year
            System.out.println("The following year you entered is not a leap year: " + year.getQueryYear());
        }
    }
}
