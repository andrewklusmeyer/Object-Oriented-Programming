//Defines a public class named IsLeapYear
public class IsLeapYear
{
    //Declares a private integer variable named queryYear
    private int queryYear;

    //Constructor: Initializes the queryYear variable with the provided 'year'
    public IsLeapYear(int year)
    {
        queryYear = year;
    }

    //Method to set the queryYear variable to a new value 'inputYear'
    public void setQueryYear(int inputYear)
    {
        queryYear = inputYear;
    }

    //Method to retrieve the current value of the queryYear variable
    public int getQueryYear()
    {
        return queryYear;
    }
}
