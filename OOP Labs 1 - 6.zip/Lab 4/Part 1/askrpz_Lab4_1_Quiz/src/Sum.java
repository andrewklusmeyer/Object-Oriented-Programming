public class Sum
{
    //Declare private instance variables to store three integer values.
    private int firstInt, secondInt, thirdInt;

    //Constructor to initialize the instance variables with three integers.
    public Sum(int first, int second, int third)
    {
        firstInt = first;
        secondInt = second;
        thirdInt = third;
    }

    //Method to check if it's possible to add any two values to get the third.
    public boolean twoSum() {
        //Creates an array to hold the three integer values.
        int array[] = {firstInt, secondInt, thirdInt};

        //Loops through the array to check all possible pairs of values.
        for (int i = 0; i < 3; i++)
        {
            for (int j = i + 1; j < 3; j++)
            {
                //Checks if the sum of two elements equals any of the three integers.
                if (array[i] + array[j] == firstInt || array[i] + array[j] == secondInt || array[i] + array[j] == thirdInt)
                {
                    // If a valid pair is found, returns true.
                    return true;
                }
            }
        }
        //If no valid pair is found, returns false.
        return false;
    }
}
