import java.util.Scanner;

public class SumDemo
{
    public static void main(String[] args)
    {
        //Declares variables to store three integer values.
        int first, second, third;

        //Creates a Scanner object to read input from the keyboard.
        Scanner keyboard = new Scanner(System.in);

        //Prompts the user to enter the first integer and read it from the keyboard.
        System.out.printf("First Number: ");
        first = keyboard.nextInt();

        //Prompts the user to enter the second integer and read it from the keyboard.
        System.out.printf("Second Number: ");
        second = keyboard.nextInt();

        //Prompts the user to enter the third integer and read it from the keyboard.
        System.out.printf("Third Number: ");
        third = keyboard.nextInt();

        //Creates an instance of the Sum class with the three entered integers.
        Sum numbers = new Sum(first, second, third);

        //Calls the twoSum method on the Sum object and check its result.
        if (numbers.twoSum())
        {
            //If twoSum returns true, print "True."
            System.out.println("True");
        }
        else
        {
            //If twoSum returns false, print "False."
            System.out.println("False");
        }
    }
}
