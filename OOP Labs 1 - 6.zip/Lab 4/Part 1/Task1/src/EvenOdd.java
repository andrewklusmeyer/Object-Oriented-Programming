//Defines a public class named EvenOdd
public class EvenOdd
{
    //Declares a private integer variable named queryInt
    private int queryInt;

    //Constructor: Initializes the queryInt variable with the provided 'number'
    public EvenOdd(int number)
    {
        queryInt = number;
    }

    //Method to set the queryInt variable to a new value 'inputInt'
    public void setQueryInt(int inputInt)
    {
        queryInt = inputInt;
    }

    //Method to retrieve the current value of the queryInt variable
    public int getQueryInt()
    {
        return queryInt;
    }
}
