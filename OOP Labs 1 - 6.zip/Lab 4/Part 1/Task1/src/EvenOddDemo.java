//Import the Scanner class from the java.util package, allowing user input
import java.util.Scanner;

//Defines a public class named EvenOddDemo
public class EvenOddDemo
{
    public static void main(String[] args)
    {
        //Declares an integer variable to store user input
        int inputNumber;

        //Creates a Scanner object named 'keyboard' to read input from the keyboard
        Scanner keyboard = new Scanner(System.in);

        //Prompts the user to enter an integer
        System.out.printf("Enter the query integer: ");

        //Reads the integer entered by the user and store it in 'inputNumber'
        inputNumber = keyboard.nextInt();

        //Creates an instance of the 'EvenOdd' class with the 'inputNumber' as an argument
        EvenOdd number = new EvenOdd(inputNumber);

        //Checks if the 'inputNumber' is even (divisible by 2)
        if (inputNumber % 2 == 0)
        {
            //Displays a message indicating that the number is even
            System.out.println("The following number you inputted is even: " + number.getQueryInt());
        }
        else
        {
            // Displays a message indicating that the number is odd
            System.out.println("The following number you inputted is odd: " + number.getQueryInt());
        }
    }
}
