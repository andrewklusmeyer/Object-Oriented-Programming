//Defines a public class named MagicDate
public class MagicDate
{
    //Declares private integer variables to store month, day, and year
    private int month, day, year;

    //Defines a constructor for the MagicDate class that takes three integer parameters
    public MagicDate (int m, int d, int y)
    {
        //Initializes the private variables 'month', 'day', and 'year' with the values passed as parameters
        month = m;
        day = d;
        year = y;
    }

    //Defines a public method named 'isMagic' that returns a boolean value
    public boolean isMagic()
    {
        //Checks if the product of 'month' and 'day' is equal to 'year'
        if((month * day) == year)
        {
            //If the condition is true, returns 'true' to indicate that the date is magic
            return true;
        }
        else
        {
            //If the condition is false, returns 'false' to indicate that the date is not magic
            return false;
        }
    }
}
