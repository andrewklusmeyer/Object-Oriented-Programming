//Imports the Scanner class from the java.util package for user input
import java.util.Scanner;

//Defines a public class named MagicDatesDemo
public class MagicDatesDemo
{
    public static void main(String args[])
    {
        //Declares integer variables to store user input for month, day, and year
        int inputMonth, inputDay, inputYear;

        //Creates a new Scanner object named 'keyboard' to read user input from the console
        Scanner keyboard = new Scanner(System.in);

        //Prompts the user to enter an integer representing the month and store it in 'inputMonth'
        System.out.print("Enter the integer representing the month: ");
        inputMonth = keyboard.nextInt();

        //Prompts the user to enter an integer representing the day and store it in 'inputDay'
        System.out.print("Enter the integer representing the day: ");
        inputDay = keyboard.nextInt();

        //Prompts the user to enter an integer representing the year and store it in 'inputYear'
        System.out.print("Enter the integer representing the year: ");
        inputYear = keyboard.nextInt();

        //Creates a new MagicDate object named 'date' using the provided input values
        MagicDate date = new MagicDate(inputMonth, inputDay, inputYear);

        //Checks if the 'date' is a magic date by calling the 'isMagic()' method of the MagicDate class
        if (date.isMagic())
        {
            //If it's a magic date, prints a message indicating so
            System.out.println("The date you entered is magic!");
        }
        else
        {
            //If it's not a magic date, prints a message indicating so
            System.out.println("The date you entered is not magic");
        }
    }
}
