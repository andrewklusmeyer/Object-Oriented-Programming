//Imports the Scanner class from the java.util package
import java.util.Scanner;

//Defines a public class named "PrintSquares"
public class PrintSquares
{
    public static void main(String[] args)
    {
        //Declares integer variables to store user input and a counter
        int userInput;
        int counter = 1;

        //Creates a new Scanner object named "keyboard" for user input
        Scanner keyboard = new Scanner(System.in);

        //Prompts the user to enter an integer
        System.out.println("Enter your integer value: ");

        //Reads an integer input from the user and store it in "userInput"
        userInput = keyboard.nextInt();

        //Displays a message indicating that we will print squares
        System.out.println("These are the following squares before your value: ");

        //Starts a while loop that continues as long as the square of "counter" is less than or equal to "userInput"
        //and "counter" itself is less than or equal to "userInput"
        while((counter * counter) <= userInput && counter <= userInput)
        {
            //Prints the square number and the value of the square
            System.out.println("Square " + counter + ": " + (counter * counter));

            //Increments the "counter" variable by 1 for the next iteration
            counter++;
        }
    }
}
