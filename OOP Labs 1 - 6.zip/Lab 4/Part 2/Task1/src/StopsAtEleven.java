//Imports the Scanner class from the java.util package to allow user input.
import java.util.Scanner;

//Declares a public class named StopsAtEleven.
public class StopsAtEleven
{
    public static void main(String args[])
    {
        //Declares and initialize variables for user input and a counter.
        int userInput = 0;
        int counter = 0;

        //Creates a Scanner object called 'keyboard' to read input from the user.
        Scanner keyboard = new Scanner(System.in);

        //Prompts the user to enter an integer value.
        System.out.println("Enter an integer value: ");

        //Reads an integer from the user and store it in the 'userInput' variable.
        userInput = keyboard.nextInt();

        //Creates a loop that continues as long as 'userInput' is not equal to 11
        //and 'userInput' is greater than or equal to 0.
        while(userInput != 11 && userInput >= 0)
        {
            //Prompts the user to enter another integer value.
            System.out.println("Enter another integer value: ");

            //Reads the next integer input from the user and store it in 'userInput'.
            userInput = keyboard.nextInt();

            //Increments the 'counter' variable by 1.
            counter++;
        }

        //After the loop ends, prints the number of valid values entered by the user
        //that weren't equal to 11.
        System.out.println("You entered " + counter + " valid values that weren't 11.");
    }
}
