public class NestedForLoop
{
    public static void main(String[] args)
    {
        //Outer loop to control the rows
        for(int row = 1; row <= 5; row++)
        {
            //Inner loop to control the columns
            for(int column = 1; column <= 5; column++)
            {
                //Checks if the current row number is equal to the current column number
                if(row == column)
                {
                    //If row equals column, prints an asterisk (*)
                    System.out.print("*");
                }
                else
                {
                    //If row doesn't equal column, prints a dash (-)
                    System.out.print("-");
                }
            }

            //After printing a row of characters, moves to the next line
            System.out.println();
        }
    }
}
