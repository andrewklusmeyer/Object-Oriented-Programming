//Imports the Scanner class from the java.util package
import java.util.Scanner;

//Defines a public class named "FizzBuzz"
public class FizzBuzz
{
   public static void main(String[] args)
   {
        //Declares integer variables to store user input for two integers and a temporary integer variable
        int userInput1, userInput2;
        int tempInt;

        //Creates a new Scanner object named "keyboard" for user input
        Scanner keyboard = new Scanner(System.in);

        //Prompts the user to enter two integer values separated by a space
        System.out.println("Enter two integer values separated by a space: ");

        //Reads the first integer input from the user and store it in "userInput1"
        userInput1 = keyboard.nextInt();

        //Reads the second integer input from the user and store it in "userInput2"
        userInput2 = keyboard.nextInt();

        //Checks if userInput2 is less than userInput1, and if so, swaps the values using a temporary variable
        if (userInput2 < userInput1)
        {
            tempInt = userInput2;
            userInput2 = userInput1;
            userInput1 = tempInt;
        }

        //Loops through numbers from userInput1 to userInput2
        for(int i = userInput1; i <= userInput2; i++)
        {
            //Checks if the current number "i" is divisible by 3
            if(i % 3 == 0)
            {
                //If it is, checks if it is also divisible by 5
                if (i % 5 == 0)
                {
                    System.out.println("FizzBuzz");
                }
                else
                {
                    //If not divisible by 5, prints "Fizz"
                    System.out.println("Fizz");
                }
                //Continues to the next iteration of the loop
                continue;
            }

            //Checks if the current number "i" is divisible by 5
            if(i % 5 == 0)
            {
                System.out.println("Buzz");
            }
            else
            {
                //If neither divisible by 3 nor 5, prints the current number "i"
                System.out.println(i);
            }
        }
    }
}
