//Imports the Scanner class from the java.util package
import java.util.Scanner;

//Defines a public class named "SumA2B"
public class SumA2B
{
    public static void main(String args[])
    {
        //Declares integer variables to store user input for the first integer, second integer, and the sum
        int userInput1, userInput2, sumAll = 0;

        //Creates a new Scanner object named "keyboard" for user input
        Scanner keyboard = new Scanner(System.in);

        //Prompts the user to enter the first integer
        System.out.println("Enter your first integer: ");

        //Reads an integer input from the user and store it in "userInput1"
        userInput1 = keyboard.nextInt();

        //Prompts the user to enter the second integer
        System.out.println("Enter your second integer: ");

        //Reads an integer input from the user and store it in "userInput2"
        userInput2 = keyboard.nextInt();

        //Loops through numbers from "userInput1" to "userInput2"
        for(int i = userInput1; i <= userInput2; i++)
        {
            //Adds the current value of "i" to the "sumAll" variable
            sumAll += i;
        }

        //Displays the sum of all numbers between "userInput1" and "userInput2"
        System.out.println("The sum of all numbers between " + userInput1 + " and " + userInput2 + ": " + sumAll);
    }
}
