//Defines a public class named "CoinTossSimulator"
public class CoinTossSimulator
{
    public static void main(String[] args)
    {
        //Initializes integer variables to count the number of heads and tails
        int headCount = 0, tailCount = 0;

        //Creates a new Coin object called "tossedCoin" and set its initial side to "Heads"
        Coin tossedCoin = new Coin("Heads");

        //Prints the initial side of the coin
        System.out.println("Initial Side of the Coin: " + tossedCoin.getSideUp());

        //Prints a message indicating that the coin will be tossed 10 times
        System.out.println("The coin will now be tossed 10 times:");

        //Loops to simulate tossing the coin 10 times
        for(int i = 1; i <= 10; i++)
        {
            //Calls the "toss" method on the "tossedCoin" object to simulate a coin toss
            tossedCoin.toss();

            //Checks if the side of the coin facing up is "Heads"
            if(tossedCoin.getSideUp() == "Heads")
            {
                //If it's heads, increments the headCount variable
                headCount++;
            }
            else
            {
                //If it's not heads, increments the tailCount variable
                tailCount++;
            }

            //Prints the result of the current toss
            System.out.println("Toss " + i + ": " + tossedCoin.getSideUp());
        }

        //Prints the total number of heads and tails obtained in the 10 tosses
        System.out.println("Total of " + headCount + " Heads and " + tailCount + " Tails.");
    }
}
