//Imports the Random class from the java.util package
import java.util.Random;

//Defines a public class named "Coin"
public class Coin
{
    //Declares a private instance variable "sideUp" to store the side of the coin facing up
    private String sideUp;

    //Defines a constructor that takes a string argument "coinSide"
    public Coin(String coinSide)
    {
        //Sets the "sideUp" instance variable to the value of "coinSide"
        sideUp = coinSide;
    }

    //Defines a method named "toss" to simulate tossing the coin
    public void toss()
    {
        //Creates a new Random object called "rand" for generating random numbers
        Random rand = new Random();

        //Generates a random integer (either 0 or 1)
        int rand_int1 = rand.nextInt(2);

        //Checks if the random integer is equal to 1 (Heads)
        if(rand_int1 == 1)
        {
            //Sets the "sideUp" instance variable to "Heads"
            sideUp = "Heads";
        }
        else
        {
            //If the random integer is not 1, sets the "sideUp" instance variable to "Tails"
            sideUp = "Tails";
        }
    }

    //Defines a method named "getSideUp" to retrieve the current side of the coin facing up
    public String getSideUp()
    {
        //Returns the value of the "sideUp" instance variable
        return sideUp;
    }
}
