//Imports the Scanner class from the java.util package
import java.util.Scanner;

//Defines a public class named "SumAll"
public class SumAll
{
    public static void main(String args[])
    {
        //Initializes variables to hold user input, total, and a counter
        int userInput = 0; //Stores the user's input integer
        int total = 0;     //Stores the sum of numbers
        int counter = 0;   //Used to iterate through numbers

        //Creates a new Scanner object named "keyboard" for user input
        Scanner keyboard = new Scanner(System.in);

        //Prompts the user to enter an integer
        System.out.println("Enter your integer value: ");
        //Reads an integer input from the user and store it in "userInput"
        userInput = keyboard.nextInt();

        do
        {
            //Adds the current value of "counter" to the "total" variable
            total += counter;
            //Increments the "counter" variable by 1
            counter++;
        }
        //Continues the loop while "userInput" is greater than 0 and "counter" is less than or equal to "userInput"
        while(userInput > 0 && counter <= userInput);

        //Displays the sum of all numbers from 1 to the user's input value
        System.out.println("The sum of all numbers from 1 - " + userInput + ": " + total);
    }
}
