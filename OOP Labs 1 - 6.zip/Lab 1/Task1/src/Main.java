class Task1
{
    public static void main(String[] args)
    {
        System.out.println("Hello to 3330 course!");
    }

}