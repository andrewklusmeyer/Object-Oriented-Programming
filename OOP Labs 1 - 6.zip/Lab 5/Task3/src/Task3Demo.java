import java.util.Arrays;

// A class named Task3Demo that demonstrates the utility methods of the SequenceOperations class
public class Task3Demo
{
    public static void main(String[] args)
    {
        // Initializing an array with the provided values
        double[] arrayValues = {3.0, 2.4, 6.0, 2.0, 4.0, 5.1, 7.2};

        // Displaying the array values
        System.out.println("Processing the array: " + Arrays.toString(arrayValues));

        // Displaying the total of the values in the array
        System.out.println("Total: " + SequenceOperations.getTotal(arrayValues));

        // Displaying the average of the values in the array
        System.out.printf("Average: %.2f\n", SequenceOperations.getAverage(arrayValues));

        // Displaying the highest value in the array
        System.out.println("Highest value: " + SequenceOperations.getHighest(arrayValues));

        // Displaying the reversed array
        System.out.println("Array Reverse: " + Arrays.toString(SequenceOperations.getReverse(arrayValues)));
    }
}
