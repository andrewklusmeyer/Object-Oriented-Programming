public class SequenceOperations
{
    public static double getTotal(double[] numbers)
    {
        //Initialize a double variable 'total' and set its value to 0. This variable will store the sum of the array's elements.
        double total = 0;

        //Iterate over each element in the 'numbers' array.
        for (double num : numbers)
        {
            //Add the current element's value to the 'total' variable.
            total += num;
        }

        //After all elements have been added, return the total sum.
        return total;
    }

    public static double getAverage(double[] numbers)
    {
        //Return the average value of the array. This is done by calling the getTotal method to sum all elements,
        //and then dividing that sum by the number of elements (length of the array).
        return getTotal(numbers) / numbers.length;
    }

      public static double getHighest(double[] numbers)
    {
        //Initialize a double variable 'highest' with the first element of the 'numbers' array as this is our starting point for comparison.
        double highest = numbers[0];

        //Iterate over each element in the 'numbers' array.
        for (double num : numbers)
        {
            //If the current element is greater than the highest value found so far,
            if (num > highest)
            {
                //Update 'highest' with the current element.
                highest = num;
            }
        }

        //After all elements have been compared, return the highest value.
        return highest;
    }

    public static double[] getReverse(double[] numbers)
    {
        //Create a new double array 'reversed' with the same length as the 'numbers' array.
        double[] reversed = new double[numbers.length];

        //Iterate over each index of the 'numbers' array.
        for (int i = 0; i < numbers.length; i++)
        {
            //The index for 'numbers' array is calculated as 'numbers.length - 1 - i' to start from the last element.
            reversed[i] = numbers[numbers.length - 1 - i];
        }

        //After all elements have been assigned, return the reversed array.
        return reversed;
    }
}
