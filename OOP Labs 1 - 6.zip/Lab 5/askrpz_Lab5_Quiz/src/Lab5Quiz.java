//Import the File class to handle files
import java.io.File;

//Import the FileNotFoundException class to handle errors when a file is not found
import java.io.FileNotFoundException;

//Import the PrintWriter class to write to files
import java.io.PrintWriter;

//Import the Random class to generate random numbers
import java.util.Random;

//Import the Scanner class to read from files
import java.util.Scanner;

public class Lab5Quiz
{
    public static void main(String[] args)
    {
        //Create a new File instance to represent a file named "numbers.txt"
        File file = new File("numbers.txt");

        //Use a try statement to ensure that the PrintWriter is closed at the end of the block
        try (PrintWriter printWriter = new PrintWriter(file))
        {
            //Create a new Random instance to generate random numbers
            Random random = new Random();

            //Start a for loop that iterates 10 times
            for (int i = 0; i < 10; i++)
            {
                //Generate a random number between 10 (inclusive) and 151 (exclusive) and store it in the variable number
                int number = 10 + random.nextInt(141);

                //Write the random number to the file and move to the next line
                printWriter.println(number);
            }
            //Automatically close the PrintWriter at the end of the try block to release resources
        }

        //Catch any FileNotFoundException that occurs when trying to open the file with PrintWriter
        catch (FileNotFoundException e)
        {
            //Print an error message if the file cannot be created
            System.err.println("Unable to create the file.");

            //Print the stack trace for the exception to help diagnose the error
            e.printStackTrace();
        }

        //Use a try statement to ensure that the Scanner is closed at the end of the block
        try (Scanner scanner = new Scanner(file))
        {
            //Initialize a variable to hold the sum of the numbers
            int sum = 0;

            //Initialize a counter to count the number of numbers read from the file
            int count = 0;

            //Iterate through all integers in file
            while (scanner.hasNextInt())
            {
                //Add the next integer to the sum
                sum += scanner.nextInt();

                //Increment the count of numbers
                count++;
            }

            //Checks for non-empty file
            if (count > 0)
            {
                //Calculate the average of the numbers
                double average = (double) sum / count;

                //Print the average
                System.out.println("The average value is: " + average);
            }


            else
            {
                //Print a message indicating that the file is empty
                System.out.println("The file is empty.");
            }
            //Automatically close the Scanner at the end of the try block to release resources
        }

        //Catch any FileNotFoundException that occurs when trying to open the file with Scanner
        catch (FileNotFoundException e)
        {
            //Print an error message to the standard error stream if the file cannot be opened
            System.err.println("Unable to open the file.");

            //Print the stack trace for the exception to help diagnose the error
            e.printStackTrace();
        }
    }
}
