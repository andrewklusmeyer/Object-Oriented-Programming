//Import necessary classes for file reading and checking file existence
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

public class FileDisplay
{
    //Private member variable to store the name of the file
    private final String filename;

    //Constructor for the FileDisplay class that accepts the filename as an argument
    public FileDisplay(String filename)
    {
        //Assigning the passed filename to the member variable
        this.filename = filename;
    }

    //Method to display the entire content of the file
    public void display()
    {
        //Invoking the private helper method with default values meaning "display all"
        displayContents(-1, -1);
    }

    //Overloaded method to display the first n lines of the file
    public void display(int n)
    {
        //Invoking the private helper method to display from the first line to the nth line
        displayContents(1, n);
    }

    //Overloaded method to display content of the file from a starting line to an ending line
    public void display(int from, int to)
    {
        //Invoking the private helper method with the provided starting and ending lines
        displayContents(from, to);
    }

    //Private helper method to display the content of the file between two line numbers
    private void displayContents(int from, int to)
    {
        //Using try-with-resources to ensure BufferedReader closes automatically
        try (BufferedReader br = new BufferedReader(new FileReader(filename)))
        {
            //Check if the file exists using the NIO Files class
            if (!Files.exists(Paths.get(filename)))
            {
                //If file doesn't exist, print an error message
                System.out.println("The file does not exists");

                //Exit the method early as there's no file to read from
                return;
            }

            //Variable to hold each line read from the file
            String line;

            //Counter to keep track of the current line number
            int lineNumber = 0;

            //Loop through each line in the file until there's no more lines to read
            while ((line = br.readLine()) != null)
            {
                //Increment the line number for each iteration
                lineNumber++;

                //If we are looking for a starting line and haven't reached it, skip this iteration
                if (from != -1 && lineNumber < from) continue;

                //If we have read past the ending line, break out of the loop
                if (to != -1 && lineNumber > to) break;

                //Print the current line to the console
                System.out.println(line);
            }
        }

        //Catch block to handle any IO exceptions that might occur during file reading
        catch (IOException e)
        {
            //Print the stack trace for the exception for debugging purposes
            e.printStackTrace();
        }
    }
}
