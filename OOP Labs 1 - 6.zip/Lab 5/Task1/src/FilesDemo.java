

public class FilesDemo
{

    public static void main(String[] args)
    {
        //Creating an instance of the FileSave class, targeting the file named "lines.txt"
        FileSave fileSave = new FileSave("lines.txt");

        //Initializing an array of strings named 'lines' with predefined text
        String[] lines =
                {

                "1-Lorem ipsum dolor sit amet",
                "2-Consectetuer adipiscing elit",
                "3-Sed diam nonummy nibh euismod tincidunt",
                "4-Ut wisi enim ad minim veniam",
                "5-Quis nostrud exerci tation ullamcorper",
                "6-Suscipit lobortis nisl ut aliquip ex ea commodo consequat",
                "7-Duis autem vel eum iriure dolor in hendrerit",
                "8-Vel illum dolore eu feugiat nulla facilisis at vero eros"

                };

        for (String line : lines)
        {
            //Calling the 'save' method of the fileSave object to save each line to the file
            fileSave.save(line);
        }

        //Creating an instance of the FileDisplay class, targeting the file named "lines.txt"
        FileDisplay fileDisplay = new FileDisplay("lines.txt");

        //Calling the 'display' method to display the entire content of the file
        fileDisplay.display();

        //Calling the 'display' method to display the first 3 lines of the file
        fileDisplay.display(3);

        //Calling the 'display' method to display the first 10 lines of the file
        fileDisplay.display(10);

        //Calling the 'display' method to show content from the 3rd to the 5th line of the file
        fileDisplay.display(3, 5);
    }
}
