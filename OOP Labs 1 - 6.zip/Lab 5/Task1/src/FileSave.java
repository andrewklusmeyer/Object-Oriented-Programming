//Importing necessary classes for file handling
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

//Declaring the class named FileSave
public class FileSave
{
    //A private member variable to store the name of the file
    private String filename;

    //Constructor for the FileSave class that accepts the filename as an argument
    public FileSave(String filename)
    {
        //Assigning the passed filename to the member variable
        this.filename = filename;
    }

    //Public method to save a line of text to the file
    public void save(String line)
    {
        //Using try-with-resources to automatically manage the resource. This ensures that the BufferedWriter closes automatically
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(filename, true)))
        {
            //Writing the provided line to the file
            bw.write(line);

            //Writing a newline character to move to the next line in the file
            bw.newLine();
        }

        catch (IOException e)
        {
            //If an exception occurs during file writing, print the stack trace
            e.printStackTrace();
        }
    }
}
