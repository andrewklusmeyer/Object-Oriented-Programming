import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class KidsPopularName
{

    private String[] kidsNames;

    private String fileName;

    public KidsPopularName(String fileName)
    {
        this.fileName = fileName; //Assign the provided file name to the fileName member variable
        this.fillNames(); //Call the fillNames method to read the names from the file into the kidsNames array
    }

    private int getNumNames()
    {
        //If the kidsNames array is null, return 0, otherwise return its length
        return (kidsNames == null) ? 0 : kidsNames.length;
    }

    private void fillNames()
    {
        //Exception handling for file operations
        try
        {
            //Create a File instance to reference the file with names
            File file = new File(this.fileName);

            //Create a Scanner instance to read data from the file
            Scanner scanner = new Scanner(file);

            //Count the number of names in the file
            int nameCount = 0;

            while (scanner.hasNextLine())
            {
                scanner.nextLine();
                nameCount++;
            }

            scanner.close(); //Close the scanner

            //Initialize the kidsNames array with the size of nameCount
            kidsNames = new String[nameCount];

            //Reinitialize the scanner to start reading the file again
            scanner = new Scanner(file);

            //Read each line in the file and add it to the kidsNames array
            int index = 0;

            while (scanner.hasNextLine())
            {
                kidsNames[index++] = scanner.nextLine();
            }
            scanner.close(); //Close the scanner


        }

        catch (FileNotFoundException e) //Handle the case where the file is not found
        {
            e.printStackTrace(); //Print the stack trace for the exception
        }
    }

    public boolean isPopularName(String name)
    {
        //Check if the kidsNames array contains the provided name
        for (String kidName : kidsNames)
        {
            //If the name is found in the array, return true
            if (kidName.equalsIgnoreCase(name))
            {
                return true;
            }
        }

        //If the name is not found in the array, return false
        return false;
    }
}
