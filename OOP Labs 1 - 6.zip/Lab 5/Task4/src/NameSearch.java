import java.util.Scanner;

public class NameSearch
{

    public static void main(String[] args)
    {

        //Create an instance of the 'KidsPopularName' class called 'boyNames', using "BoyNames.txt" as the file source
        KidsPopularName boyNames = new KidsPopularName("BoyNames.txt");

        //Create another instance of the 'KidsPopularName' class called 'girlNames', using "GirlNames.txt" as the file source
        KidsPopularName girlNames = new KidsPopularName("GirlNames.txt");

        //Create a Scanner object to receive user input from the console
        Scanner scanner = new Scanner(System.in);

        //Prompt the user to enter a kid's name
        System.out.print("Enter a kid's name: ");

        String name = scanner.nextLine(); //Read the user input

        //Use the 'isPopularName' method to check if the provided name is a popular boy's name
        boolean isPopularBoyName = boyNames.isPopularName(name);

        //Use the 'isPopularName' method to check if the provided name is a popular girl's name
        boolean isPopularGirlName = girlNames.isPopularName(name);

        //Display the result based on whether the name is a popular boy's or girl's name, or not popular
        if (isPopularBoyName)
        {
            System.out.println(name + " is one of the most popular boy's names.");
        }

        else if (isPopularGirlName)
        {
            System.out.println(name + " is one of the most popular girl's names.");
        }

        else
        {
            System.out.println(name + " is not one of the most popular kid's names.");
        }

        scanner.close(); //Close the Scanner
    }
}
