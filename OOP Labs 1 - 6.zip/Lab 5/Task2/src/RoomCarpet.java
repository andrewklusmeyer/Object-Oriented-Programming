
public class RoomCarpet
{
    //Declaring a private instance variable of type RoomDimension to store the size of the room
    private RoomDimension size;

    //Declaring a private instance variable of type double to store the cost of the carpet per square foot
    private double carpetCost;

    //Constructor of the RoomCarpet class that accepts a RoomDimension object and a double value for carpet cost
    public RoomCarpet(RoomDimension dim, double cost)
    {
        //Initializing the size instance variable with the provided RoomDimension object
        size = dim;

        //Initializing the carpetCost instance variable with the provided cost
        carpetCost = cost;
    }

    //Public method that returns the total cost of carpeting the room
    public double getTotalCost()
    {
        //Calculating and returning the total cost
        return (size.getArea() * carpetCost);
    }

    //Overriding the toString() method from the Object class to provide a meaningful string representation of a RoomCarpet object
    @Override
    public String toString()
    {
        //Returning a string that displays the total cost of the carpet for the room
        return "Total Cost: $" + getTotalCost();
    }
}
