//Importing the Scanner class to take user input
import java.util.Scanner;

public class CarpetCalculator
{
    public static void main(String[] args)
    {
        //Declaring three double variables to store user inputs for room dimensions and carpet cost
        double inputLength, inputWidth, inputCost;

        //Creating an instance of the Scanner class to read user input
        Scanner keyboard = new Scanner(System.in);

        //Prompting the user to enter the price per square foot for the carpet
        System.out.println("Enter the price per square foot: ");

        //Storing the user's input as a double value in the inputCost variable
        inputCost = keyboard.nextDouble();

        //Prompting the user to enter the length of the room
        System.out.println("Enter the length of the room: ");

        //Storing the user's input as a double value in the inputLength variable
        inputLength = keyboard.nextDouble();

        //Prompting the user to enter the width of the room
        System.out.println("Enter the width of the room: ");

        //Storing the user's input as a double value in the inputWidth variable
        inputWidth = keyboard.nextDouble();

        //Creating an instance of the RoomDimension class using the user inputs for length and width
        RoomDimension room = new RoomDimension(inputLength, inputWidth);

        //Creating an instance of the RoomCarpet class using the RoomDimension object and the user input for carpet cost
        RoomCarpet carpet = new RoomCarpet(room, inputCost);

        //Displaying a header indicating that the room dimensions will be printed next
        System.out.println("Room Dimensions: ");

        //Printing the string representation of the RoomDimension object
        System.out.println(room);

        //Printing the string representation of the RoomCarpet object
        System.out.println(carpet);
    }
}
