
public class RoomDimension
{

    //Declaring two private instance variables of type double to store the length and width of the room
    private double length, width;

    //Constructor of the RoomDimension class that accepts two double values for length and width
    public RoomDimension(double len, double w)
    {
        //Initializing the length instance variable with the provided length value
        length = len;

        //Initializing the width instance variable with the provided width value
        width = w;
    }

    public double getArea()
    {
        //Calculating and returning the area by multiplying the length and width of the room
        return (length * width);
    }

    //Overriding the toString() method from the Object class to provide a meaningful string representation of a RoomDimension object
    @Override
    public String toString()
    {
        //Returning a string that displays the length, width, and calculated area of the room
        return "Length: " + length +
                ", Width: " + width +
                ", Area: " + getArea();
    }
}
