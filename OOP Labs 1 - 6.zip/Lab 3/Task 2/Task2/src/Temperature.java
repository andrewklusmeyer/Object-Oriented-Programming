//Creates a class named Temperature
public class Temperature
{
    //Declares a private instance variable 'fTemp' to store the Fahrenheit temperature
    private double fTemp;

    //Constructor that takes a parameter 'temp' and initializes the 'fTemp' variable with it
    public Temperature(double temp)
    {
        fTemp = temp;
    }

    //Setter method to update the 'fTemp' value with the provided temperature 't'
    public void setFahrenheit(double t)
    {
        fTemp = t;
    }

    //Getter method to retrieve the current Fahrenheit temperature
    public double getFahrenheit()
    {
        return fTemp;
    }

    //Calculates and return the Celsius equivalent of the Fahrenheit temperature
    public double getCelsius()
    {
        return (5.0 / 9.0) * (fTemp - 32);
    }

    //Calculates and return the Kelvin equivalent of the Fahrenheit temperature
    public double getKelvin()
    {
        return (5.0 / 9.0) * (fTemp - 32) + 273.15;
    }
}
