//Imports the Scanner class from the java.util package to read input from the user
import java.util.Scanner;

//Creates a class named TemperatureDemo
public class TemperatureDemo
{
    //The main method, where the program starts execution
    public static void main(String[] args)
    {
        //Declares a variable to store the Fahrenheit temperature
        double fTemperature;

        //Creates a new Scanner object called 'keyboard' to read user input from the console
        Scanner keyboard = new Scanner(System.in);

        //Prompts the user to enter a Fahrenheit temperature
        System.out.printf("Enter the Fahrenheit temperature: ");

        //Reads the user's input as a double and store it in the 'fTemperature' variable
        fTemperature = keyboard.nextDouble();

        //Creates a new Temperature object called 'temp' with the Fahrenheit temperature as an argument
        Temperature temp = new Temperature(fTemperature);

        //Displays the converted temperature in Celsius using the 'getCelsius()' method of the 'temp' object
        System.out.println("Celsius: " + temp.getCelsius());

        //Displays the converted temperature in Kelvin using the 'getKelvin()' method of the 'temp' object
        System.out.println("Kelvin: " + temp.getKelvin());
    }
}
