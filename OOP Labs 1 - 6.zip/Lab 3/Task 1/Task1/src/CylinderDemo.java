//Imports the Scanner class from the java.util package to read user input
import java.util.Scanner;

//Defines a class named "CylinderDemo"
public class CylinderDemo
{
    //Defines the main method, the entry point of the program
    public static void main(String[] args)
    {
        //Declares variables to store the cylinder's height and radius
        double cylinderHeight, cylinderRadius;

        //Creates a new Scanner object named "keyboard" to read input from the keyboard
        Scanner keyboard = new Scanner(System.in);

        //Displays a prompt asking the user to enter the radius of the cylinder
        System.out.printf("What is the radius of the cylinder? ");

        //Reads the next double value entered by the user and store it in the "cylinderRadius" variable
        cylinderRadius = keyboard.nextDouble();

        //Displays a prompt asking the user to enter the height of the cylinder
        System.out.printf("What is the height of the cylinder? ");

        //Reads the next double value entered by the user and store it in the "cylinderHeight" variable
        cylinderHeight = keyboard.nextDouble();

        //Creates a new Cylinder object named "can" with the provided radius and height
        Cylinder can = new Cylinder(cylinderRadius, cylinderHeight);

        //Displays the radius of the cylinder using the getRadius() method and concatenate it with a message
        System.out.println("Radius of Cylinder: " + can.getRadius());

        //Displays the height of the cylinder using the getHeight() method and concatenate it with a message
        System.out.println("Height of Cylinder: " + can.getHeight());

        //Calculates and display the volume of the cylinder using the getVolume() method
        System.out.println("Volume of Cylinder: " + can.getVolume());

        //Calculates and display the curved surface area of the cylinder using the getCurvedSurfaceArea() method
        System.out.println("Curved Surface Area of Cylinder: " + can.getCurvedSurfaceArea());

        //Calculates and display the total surface area of the cylinder using the getTotalSurfaceArea() method
        System.out.println("Total Surface Area of Cylinder: " + can.getTotalSurfaceArea());
    }
}
