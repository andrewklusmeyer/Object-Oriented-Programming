//Defines a class named "Cylinder"
public class Cylinder
{
    //Declares private instance variables to store the radius and height of the cylinder
    private double radius;
    private double height;

    //Declares a final constant variable to store the value of PI
    private final double PI = 3.14159;

    //Constructor for the Cylinder class, taking radius and height as parameters
    public Cylinder(double rad, double h)
    {
        //Initializes the radius and height instance variables with the values provided as parameters
        radius = rad;
        height = h;
    }

    //Setter method to set the value of the radius
    public void setRadius(double r)
    {
        //Updates the radius instance variable with the new value provided as a parameter
        radius = r;
    }

    //Setter method to set the value of the height
    public void setHeight(double h)
    {
        //Updates the height instance variable with the new value provided as a parameter
        height = h;
    }

    //Getter method to retrieve the value of the radius
    public double getRadius()
    {
        //Returns the current value of the radius instance variable
        return radius;
    }

    //Getter method to retrieve the value of the height
    public double getHeight()
    {
        //Returns the current value of the height instance variable
        return height;
    }

    //Calculates and return the volume of the cylinder
    public double getVolume()
    {
        //Uses the formula for the volume of a cylinder: PI * (radius * radius) * height
        return PI * (radius * radius) * height;
    }

    //Calculates and return the curved surface area of the cylinder
    public double getCurvedSurfaceArea()
    {
        //Uses the formula for the curved surface area of a cylinder: 2 * PI * radius * height
        return 2 * PI * radius * height;
    }

    //Calculates and return the total surface area of the cylinder
    public double getTotalSurfaceArea()
    {
        //Uses the formula for the total surface area of a cylinder: 2 * PI * radius * (height + radius)
        return 2 * PI * radius * (height + radius);
    }
}
