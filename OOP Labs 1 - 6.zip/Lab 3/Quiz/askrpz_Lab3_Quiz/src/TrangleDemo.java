import java.util.Scanner; //imports scanner tool

public class TrangleDemo
{
    public static void main(String[] args)
    {
        double dBase;
        double dHeight;
        double dLeftSide;
        double dRightSide;


        Scanner keyboard = new Scanner(System.in);

        System.out.printf("Enter the base of the triangle: "); //Uses user input and assigns it to dBase
        dBase = keyboard.nextDouble();

        System.out.printf("Enter the height of the triangle: "); //uses user input and assigns to d height
        dHeight = keyboard.nextDouble();

        System.out.printf("Enter the left side of the triangle: ");
        dLeftSide = keyboard.nextDouble();

        System.out.printf("Enter the right side of the triangle: ");
        dRightSide = keyboard.nextDouble();

        Triangle tri = new Triangle(dBase, dHeight, dLeftSide, dRightSide);

        System.out.println("The triangle's area is " + tri.getArea());
        System.out.println("The triangle's perimeter is " + tri.getPerimeter());

    }
}
