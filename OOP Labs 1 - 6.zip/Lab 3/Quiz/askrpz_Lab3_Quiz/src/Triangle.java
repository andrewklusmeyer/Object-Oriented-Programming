
public class Triangle //Class declaration
{
    private double base, height, leftSide, rightSide;

    public Triangle(double b, double h, double lS, double rS) //Constructor
    {
        base = b;
        height = h;
        leftSide = lS;
        rightSide = rS;
    }

    public void setBase(double newBase) //Setter for base
    {
        base = newBase;
    }

    public double getBase() //Getter for base
    {
        return base;
    }

    public double getArea() //Getter for Area
    {
        return (0.5 * base * height);
    }

    public double getPerimeter() //getter for perimeter
    {
        return (leftSide + base + rightSide);
    }


}